const Discord = require("discord.js")
const { JsonDatabase, } = require("wio.db");
const config = new JsonDatabase({ databasePath:"./config.json" });
const perms = new JsonDatabase({ databasePath:"./databases/myJsonPerms.json" });
const db = new JsonDatabase({ databasePath:"./databases/myJsonProdutos.json" });

module.exports = {
    name: "config", 
    description: "Configure um produto", // Coloque a descrição do comando
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
        {
            name: "id",
            description: "Id do produto",
            type: Discord.ApplicationCommandOptionType.String,
            required: true,
        }
    ],
    run: async(client,interaction, message, args) => {
        const id2 = interaction.options.getString("id")
        if(interaction.user.id !== `${perms.get(`${interaction.user.id}_id`)}`) return interaction.reply(`❌ | Você não está na lista de pessoas!`).then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));
        if(id2 !== `${db.get(`${id2}.idproduto`)}`) return interaction.reply(`❌ | Esse ID de produto não é existente!`).then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));
        
        const adb = id2;
        const row = new Discord.ActionRowBuilder()
            .addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId('descgerenciar')
                    .setEmoji('📝')
                    .setLabel('Descrição')
                    .setStyle(Discord.ButtonStyle.Success),
            )
            .addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId('nomegerenciar')
                    .setEmoji('📝')
                    .setLabel('Nome')
                    .setStyle(Discord.ButtonStyle.Success),
            )
            .addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId('precogerenciar')
                    .setEmoji('💸')
                    .setLabel('Preço')
                    .setStyle(Discord.ButtonStyle.Success),
            )
            .addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId('deletegerenciar')
                    .setEmoji('🗑')
                    .setLabel('Excluir')
                    .setStyle(Discord.ButtonStyle.Danger),
            )
            .addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId('rlgerenciar')
                    .setEmoji('🔄')
                    .setLabel('Atualizar')
                    .setStyle(Discord.ButtonStyle.Primary),
            );
        
        const msg = await interaction.reply({ 
            embeds: [
            
                new Discord.EmbedBuilder()
            
                .setTitle(`${config.get(`title`)} | Configurando o(a) ${adb}`)
            
                .setDescription(`
                📝 | Descrição: \`\`\` ${db.get(`${adb}.desc`)}\`\`\`
                🪐 | Nome: ${db.get(`${adb}.nome`)}
                💸 | Preço: ${db.get(`${adb}.preco`)} 
                📦 | Estoque: ${db.get(`${adb}.conta`).length}`)
                .setThumbnail(client.user.displayAvatarURL())
                .setColor(config.get(`color`))], components: [row]})
        
                const filter = i => i.user.id === interaction.user.id
            const interação = msg.createMessageComponentCollector({ filter })
  
            interação.on("collect", async (interaction) => {
               if (interaction.user.id != interaction.user.id) {
               return;
            }
                
                if (interaction.customId === "deletegerenciar") {
                    msg.delete()
                    msg.channel.send("🗑 | Excluido!")
                    db.delete(adb)
                }
                if (interaction.customId === "precogerenciar") {
                   interaction.deferUpdate();
                    interaction.channel.send("❓ | Qual o novo preço?").then(msg => {
                        const filter = m => m.author.id === interaction.user.id;
                        const collector = msg.channel.createMessageCollector({ filter, max: 1 });
                        collector.on("collect", message => {
                            message.delete()
                            db.set(`${adb}.preco`, `${message.content.replace(",", ".")}`)
                            msg.edit("⏰ | Alterado!")
                        })
                    })
                }
                if (interaction.customId === "nomegerenciar") {
        interaction.deferUpdate();
                   interaction.channel.send("❓ | Qual o novo nome?").then(msg => {
                        const filter = m => m.author.id === interaction.user.id;
                        const collector = msg.channel.createMessageCollector({ filter, max: 1 });
                        collector.on("collect", message => {
                            message.delete()
                            db.set(`${adb}.nome`, `${message.content}`)
                            msg.edit("⏰ | Alterado!")
                        })
                    })
                }
    if (interaction.customId === 'descgerenciar') {
        interaction.deferUpdate();
                    interaction.channel.send("❓ | Qual a nova descrição?").then(msg => {
                        const filter = m => m.author.id === interaction.user.id;
                        const collector = msg.channel.createMessageCollector({ filter, max: 1 });
                        collector.on("collect", message => {
                            message.delete()
                            db.set(`${adb}.desc`, `${message.content}`)
                            msg.edit("⏰ | Alterado!")
                        })
                    })
                }
    if (interaction.customId === 'rlgerenciar') {
        interaction.deferUpdate();
         const embed = new Discord.EmbedBuilder()
           .setTitle(`${config.get(`title`)} | Configurando o(a) ${adb}`)
           .setDescription(`
📝 | Descrição: \`\`\` ${db.get(`${adb}.desc`)}\`\`\`
🪐 | Nome: ${db.get(`${adb}.nome`)}
💸 | Preço: ${db.get(`${adb}.preco`)} 
📦 | Estoque: ${db.get(`${adb}.conta`).length}`)
           .setThumbnail(client.user.displayAvatarURL())
           .setColor(config.get(`color`))
           msg.edit({ embeds: [embed] })
           interaction.channel.send("⏰ | Atualizado!")
                }
              })
            }
           }