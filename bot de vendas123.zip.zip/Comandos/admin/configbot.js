const Discord = require("discord.js")
const { JsonDatabase, } = require("wio.db");
const config = new JsonDatabase({ databasePath:"./config.json" });
const perms = new JsonDatabase({ databasePath:"./databases/myJsonPerms.json" });

module.exports = {
    name: "configbot",  
    description: "Configure o bot", // Coloque a descrição do comando
    type: Discord.ApplicationCommandType.ChatInput,
    run: async(client, interaction, message, args) => {
      if(interaction.user.id !== `${perms.get(`${interaction.user.id}_id`)}`) return interaction.reply(`❌ | Você não está na lista de pessoas!`).then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));
      const row = new Discord.ActionRowBuilder()
        .addComponents(
          new Discord.ButtonBuilder()
            .setCustomId('nomeconfig')
            .setEmoji('📝')
            .setLabel('Nome')
            .setStyle(Discord.ButtonStyle.Secondary),
        )
        .addComponents(
          new Discord.ButtonBuilder()
            .setCustomId('corconfig')
            .setEmoji('🎨')
            .setLabel('Cor')
            .setStyle(Discord.ButtonStyle.Secondary),
        )
        .addComponents(
          new Discord.ButtonBuilder()
            .setCustomId('avatarconfig')
            .setEmoji('🖼️')
            .setLabel('Avatar')
            .setStyle(Discord.ButtonStyle.Secondary),
        )
        .addComponents(
          new Discord.ButtonBuilder()
            .setCustomId('cargoconfig')
            .setEmoji('🥇')
            .setLabel('Cargo')
            .setStyle(Discord.ButtonStyle.Secondary),
        );
        
        const embed = await interaction.reply({ embeds: [new Discord.EmbedBuilder()
          .setTitle(`${config.get(`title`)} | Configuração do bot`)
          .setDescription(`
          🪐 | Nome: **${config.get(`title`)}**
🎨 | Cor: ${config.get(`color`)}
🖼️ | Avatar: [Clique aqui](${config.get(`thumbnail`)})
🥇 | Cargo Cliente: <@&${config.get(`role`)}>`)
          .setColor(config.get(`color`))], components: [row]})
        const interação = embed.createMessageComponentCollector({ componentType: Discord.ComponentType.Button, });
          interação.on("collect", async (interaction) => {
           if (interaction.user.id != interaction.user.id) {
             return;
           }

           if (interaction.customId === "nomeconfig") {
             interaction.deferUpdate();
             interaction.channel.send("❓ | Qual o novo nome?").then(msg => {
              const filter = m => m.author.id === interaction.user.id;
              const collector = msg.channel.createMessageCollector({ filter, max: 1 });
               collector.on("collect", title => {
                 title.delete()
                 client.user.setUsername(title.content);
                 const newt = title.content
                 config.set(`title`, newt)
                 msg.edit("✅ | Alterado!")
                            
                 const embednew = new Discord.EmbedBuilder()
                   .setTitle(`${config.get(`title`)} | Configuração do bot`)
                   .setDescription(`
🪐 | Nome: **${config.get(`title`)}**
🎨 | Cor: ${config.get(`color`)}
🖼️ | Avatar: [Clique aqui](${config.get(`thumbnail`)})
🥇 | Cargo Cliente: <@&${config.get(`role`)}>`)
                   .setColor(config.get(`color`))
                 embed.edit({ embeds: [embednew] })
                 })
               })
             }
           if (interaction.customId === "corconfig") {
             interaction.deferUpdate();
             interaction.channel.send("❓ | Qual a nova cor em hex?").then(msg => {
              const filter = m => m.author.id === interaction.user.id;
              const collector = msg.channel.createMessageCollector({ filter, max: 1 });
               collector.on("collect", color => {
                 color.delete()
                 const newt = color.content
                 config.set(`color`, newt)
                 msg.edit("✅ | Alterado!")
                            
                 const embednew = new Discord.EmbedBuilder()
                   .setTitle(`${config.get(`title`)} | Configuração do bot`)
                   .setDescription(`
                   🪐 | Nome: **${config.get(`title`)}**
🎨 | Cor: ${config.get(`color`)}
🖼️ | Avatar: [Clique aqui](${config.get(`thumbnail`)})
🥇 | Cargo Cliente: <@&${config.get(`role`)}>`)
                   .setColor(config.get(`color`))
                 embed.edit({ embeds: [embednew] })
                 })
               })
             }
           if (interaction.customId === "avatarconfig") {
             interaction.deferUpdate();
             interaction.channel.send("❓ | Qual o novo avatar do bot?").then(msg => {
              const filter = m => m.author.id === interaction.user.id;
              const collector = msg.channel.createMessageCollector({ filter, max: 1 });
               collector.on("collect", thumbnail => {
                 thumbnail.delete()
                 thumbnail.attachments.forEach(attachment => {
                 const newt = attachment.proxyURL;
                 client.user.setAvatar(newt);
                 config.set(`thumbnail`, newt)});
                 msg.edit("✅ | Alterado!")
                            
                 const embednew = new Discord.EmbedBuilder()
                   .setTitle(`${config.get(`title`)} | Configuração do bot`)
                   .setDescription(`
                   🪐 | Nome: **${config.get(`title`)}**
🎨 | Cor: ${config.get(`color`)}
🖼️ | Avatar: [Clique aqui](${config.get(`thumbnail`)})
🥇 | Cargo Cliente: <@&${config.get(`role`)}>`)
                   .setColor(config.get(`color`))
                 embed.edit({ embeds: [embednew] })
                 })
               })
             }
           if (interaction.customId === "cargoconfig") {
             interaction.deferUpdate();
             interaction.channel.send("❓ | Qual o novo cargo em id?").then(msg => {
              const filter = m => m.author.id === interaction.user.id;
              const collector = msg.channel.createMessageCollector({ filter, max: 1 });
                collector.on("collect", role => {
                 role.delete()
                 const newt = role.content
                 config.set(`role`, newt)
                 msg.edit("✅ | Alterado!")
                            
                 const embednew = new Discord.EmbedBuilder()
                   .setTitle(`${config.get(`title`)} | Configuração do bot`)
                   .setDescription(`
                   🪐 | Nome: **${config.get(`title`)}**
🎨 | Cor: ${config.get(`color`)}
🖼️ | Avatar: [Clique aqui](${config.get(`thumbnail`)})
🥇 | Cargo Cliente: <@&${config.get(`role`)}>`)
                   .setColor(config.get(`color`))
                 embed.edit({ embeds: [embednew] })
                 })
               })
             }
           })
         }
       };