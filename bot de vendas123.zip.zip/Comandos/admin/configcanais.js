const Discord = require("discord.js")
const { JsonDatabase, } = require("wio.db");
const config = new JsonDatabase({ databasePath:"./config.json" });
const perms = new JsonDatabase({ databasePath:"./databases/myJsonPerms.json" });

module.exports = {
    name: "configcanais",  
    description: "Configure os Canais", // Coloque a descrição do comando
    type: Discord.ApplicationCommandType.ChatInput,
    run: async(client,interaction, message, args) => {
      if(interaction.user.id !== `${perms.get(`${interaction.user.id}_id`)}`) return interaction.reply(`❌ | Você não está na lista de pessoas!`).then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));
      const row = new Discord.ActionRowBuilder()
        .addComponents(
          new Discord.ButtonBuilder()
            .setCustomId('categoriaconfig')
            .setEmoji('🛒')
            .setLabel('Categoria Carrinho')
            .setStyle(Discord.ButtonStyle.Secondary),
        )
        .addComponents(
          new Discord.ButtonBuilder()
            .setCustomId('logsconfig')
            .setEmoji('🧾')
            .setLabel('Logs Vendas')
            .setStyle(Discord.ButtonStyle.Secondary),
        )
        .addComponents(
          new Discord.ButtonBuilder()
            .setCustomId('logs2config')
            .setEmoji('🧰')
            .setLabel('Logs Vendas Staff')
            .setStyle(Discord.ButtonStyle.Secondary),
        );
        
        const embed = await interaction.reply({ embeds: [new Discord.EmbedBuilder()
                  .setTitle(`${config.get(`title`)} | Configuração dos canais`)
                  .setDescription(`
🛒 | Categoria Carrinho: <#${config.get(`category`)}>
🧾 | Logs Vendas: <#${config.get(`logs`)}>
🧰 | Logs Vendas Staff: <#${config.get(`logs_staff`)}>`)
                  .setColor(config.get(`color`))], components: [row]})
        const interação = embed.createMessageComponentCollector({ componentType: Discord.ComponentType.Button, });
         interação.on("collect", async (interaction) => {
          if (interaction.user.id != interaction.user.id) {
           return;
          }

          if (interaction.customId === "categoriaconfig") {
            interaction.deferUpdate();
            interaction.channel.send("❓ | Qual a nova de categoria dos carrinhos em id?").then(msg => {
             const filter = m => m.author.id === interaction.user.id;
             const collector = msg.channel.createMessageCollector({ filter, max: 1 });
              collector.on("collect", category => {
                category.delete()
                const newt = category.content
                config.set(`category`, newt)
                msg.edit("✅ | Alterado!")
                            
                const embednew = new Discord.EmbedBuilder()
                  .setTitle(`${config.get(`title`)} | Configuração dos canais`)
                  .setDescription(`
🛒 | Categoria Carrinho: <#${config.get(`category`)}>
🧾 | Logs Vendas: <#${config.get(`logs`)}>
🧰 | Logs Vendas Staff: <#${config.get(`logs_staff`)}>`)
                  .setColor(config.get(`color`))
                embed.edit({ embeds: [embednew] })
                })
              })
            }
           if (interaction.customId === "logsconfig") {
            interaction.deferUpdate();
            interaction.channel.send("❓ | Qual o novo canal de logs de vendas em id?").then(msg => {
             const filter = m => m.author.id === interaction.user.id;
             const collector = msg.channel.createMessageCollector({ filter, max: 1 });
              collector.on("collect", logs => {
                logs.delete()
                const newt = logs.content
                config.set(`logs`, newt)
                msg.edit("✅ | Alterado!")
                            
                const embednew = new Discord.EmbedBuilder()
                  .setTitle(`${config.get(`title`)} | Configuração dos canais`)
                  .setDescription(`
<a:carregando_2:1121658406734934121> | Categoria: <#${config.get(`category`)}>
🧾 | Logs: <#${config.get(`logs`)}>
🧰 | Logs Staff: <#${config.get(`logs_staff`)}>`)
                  .setColor(config.get(`color`))
                embed.edit({ embeds: [embednew] })
                })
              })
            }
                      
          if (interaction.customId === "logs2config") {
            interaction.deferUpdate();
            interaction.channel.send("❓ | Qual o novo canal de logs de vendas staff em id?").then(msg => {
             const filter = m => m.author.id === interaction.user.id;
             const collector = msg.channel.createMessageCollector({ filter, max: 1 });
              collector.on("collect", logs_staff => {
                logs_staff.delete()
                const newt = logs_staff.content
                config.set(`logs_staff`, newt)
                msg.edit("✅ | Alterado!")
                            
                const embednew = new Discord.EmbedBuilder()
                  .setTitle(`${config.get(`title`)} | Configuração dos canais`)
                  .setDescription(`
🛒 | Categoria Carrinho: <#${config.get(`category`)}>
🧾 | Logs Vendas: <#${config.get(`logs`)}>
🧰 | Logs Vendas Staff: <#${config.get(`logs_staff`)}>`)
                  .setColor(config.get(`color`))
                embed.edit({ embeds: [embednew] })
                })
              })
            }
          })
        }
      };