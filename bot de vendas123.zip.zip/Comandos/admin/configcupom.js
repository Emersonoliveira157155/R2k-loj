const Discord = require("discord.js")
const { JsonDatabase, } = require("wio.db");
const config = new JsonDatabase({ databasePath:"./config.json" });
const perms = new JsonDatabase({ databasePath:"./databases/myJsonPerms.json" });
const db = new JsonDatabase({ databasePath:"./databases/myJsonCupons.json" });

module.exports = {
    name: "configcupom",  
    description: "Configure os cupom",
    type: Discord.ApplicationCommandType.ChatInput, // Coloque a descrição do comando
    options: [
        {
            name: "id",
            description: "Id do cupom",
            type: Discord.ApplicationCommandOptionType.String,
            required: true,
        }
    ],
    
    run: async(client,interaction, message, args) => {
      const id2 = interaction.options.getString("id")
      if(interaction.user.id !== `${perms.get(`${interaction.user.id}_id`)}`) return interaction.reply(`❌ | Você não está na lista de pessoas!`).then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));
      if(id2 !== `${db.get(`${id2}.idcupom`)}`) return interaction.reply(`❌ | Esse ID de cupom não é existente!`).then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));
        
      const adb = id2;
      const row = new Discord.ActionRowBuilder()
        .addComponents(
          new Discord.ButtonBuilder()
            .setCustomId('qtdcupom')
            .setEmoji('📦')
            .setLabel('Quantidade')
            .setStyle(Discord.ButtonStyle.Secondary),
        )
        .addComponents(
          new Discord.ButtonBuilder()
            .setCustomId('mincupom')
            .setEmoji('➖')
            .setLabel('Mínimo')
            .setStyle(Discord.ButtonStyle.Secondary),
        )
        .addComponents(
          new Discord.ButtonBuilder()
            .setCustomId('pctcupom')
            .setEmoji('📊')
            .setLabel('Porcentagem')
            .setStyle(Discord.ButtonStyle.Secondary),
        )
        .addComponents(
          new Discord.ButtonBuilder()
            .setCustomId('delcupom')
            .setEmoji('🗑️')
            .setLabel('Excluir')
            .setStyle(Discord.ButtonStyle.Secondary),
        )
        .addComponents(
          new Discord.ButtonBuilder()
            .setCustomId('relcupom')
            .setEmoji('🔄')
            .setLabel('Atualizar')
            .setStyle(Discord.ButtonStyle.Secondary),
        );
        
        const msg = await interaction.reply({ embeds: [new Discord.EmbedBuilder()
          .setTitle(`${config.get(`title`)} | Configurando o(a) ${adb}`)
          .setDescription(`
          📦 | Quantidade: ${db.get(`${adb}.quantidade`)}
          <a:carregando:1162260311240351755> | Mínimo: ${db.get(`${adb}.minimo`)} 
📊 | Porcentagem: ${db.get(`${adb}.desconto`)}%`)
          .setThumbnail(client.user.displayAvatarURL())
          .setColor(config.get(`color`))], components: [row]})
        const interação = msg.createMessageComponentCollector({ componentType: Discord.ComponentType.Button, })
        interação.on("collect", async (interaction) => {
         if (interaction.user.id != interaction.user.id) {
          return;
         }
                
         if (interaction.customId === "delcupom") {
           msg.delete()
           interaction.channel.send("<a:carregando:1162260311240351755>| Excluido!")
           db.delete(`${adb}`)
         }
         if (interaction.customId === "qtdcupom") {
             interaction.deferUpdate();
             interaction.channel.send("❓ | Qual a nova quantidade de usos?").then(msg => {
               const filter = m => m.author.id === interaction.user.id;
               const collector = msg.channel.createMessageCollector({ filter, max: 1 });
               collector.on("collect", message => {
                 message.delete()
                 if (isNaN(message.content)) return msg.edit("❌ | Não coloque nenhum caractere especial além de números.")
                 db.set(`${adb}.quantidade`, `${message.content}`)
                 msg.edit("<a:carregando:1162260311240351755> | Alterado!")
             })
           })
         }
         if (interaction.customId === "mincupom") {
             interaction.deferUpdate();
             interaction.channel.send("❓ | Qual o novo mínimo para uso em ?").then(msg => {
               const filter = m => m.author.id === interaction.user.id;
               const collector = msg.channel.createMessageCollector({ filter, max: 1 });
               collector.on("collect", message => {
                 message.delete()
                 db.set(`${adb}.minimo`, `${message.content.replace(",", ".")}`)
                 msg.edit("<a:carregando:1162260311240351755> | Alterado!")
             })
           })
         }
         if (interaction.customId === 'pctcupom') {
             interaction.deferUpdate();
             interaction.channel.send("❓ | Qual o novo desconto em porcentagem?").then(msg => {
               const filter = m => m.author.id === interaction.user.id;
               const collector = msg.channel.createMessageCollector({ filter, max: 1 });
               collector.on("collect", message => {
                 message.delete()
                 if(isNaN(message.content)) return msg.edit("❌ | Não coloque nenhum caractere especial além de números.")
                 db.set(`${adb}.desconto`, `${message.content}`)
                 msg.edit("<a:carregando:1162260311240351755> | Alterado!")
             })
           })
         }
         if (interaction.customId === 'relcupom') {
           interaction.deferUpdate();
           const embed = new Discord.EmbedBuilder()
             .setTitle(`${config.get(`title`)} | Configurando o(a) ${adb}`)
             .setDescription(`
             📦 | Quantidade: ${db.get(`${adb}.quantidade`)}
<a:carregando:1162260311240351755> | Mínimo: ${db.get(`${adb}.minimo`)} 
💸 | Desconto: ${db.get(`${adb}.desconto`)}%`)
             .setThumbnail(client.user.displayAvatarURL())
             .setColor(config.get(`color`))
           msg.edit({ embeds: [embed] })
           interaction.channel.send("<a:carregando:1162260311240351755> | Atualizado!")
             }
           })
         }
       }