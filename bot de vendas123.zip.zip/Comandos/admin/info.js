const Discord = require("discord.js")
const { JsonDatabase, } = require("wio.db");
const db3 = new JsonDatabase({ databasePath:"./databases/myJsonIDs.json" });
const config = new JsonDatabase({ databasePath:"./config.json" });

module.exports = {
    name: "info",
    description: "Veja as informações de uma compra", 
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
        {
            name: "id",
            description: "Id de uma compra",
            type: Discord.ApplicationCommandOptionType.String,
            required: true,
        },
      ],
    run: async(client, interaction, message, args) => {
      const id2 = interaction.options.getString("id")
      if(id2 !== `${db3.get(`${id2}.id`)}`) return interaction.reply(`❌ | Esse ID de compra não é existente!`).then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));

      const embed = new Discord.EmbedBuilder()
        .setTitle(`${config.get(`title`)} | Compra Aprovada`)
        .addFields({name: `🪪 | ID Da compra:`,value: `${db3.get(`${id2}.id`)}`})
        .addFields({name: `🍃 | Status:`,value: `${db3.get(`${id2}.status`)}`})
        .addFields({name:`👦 | Comprador:`,value: `<@${db3.get(`${id2}.userid`)}>`})
        .addFields({name:`🪪 | Id Comprador:`, value:`${db3.get(`${id2}.userid`)}`})
        .addFields({name:`📅 | Data da compra:`, value:`${db3.get(`${id2}.dataid`)}`})
        .addFields({name:`🪪 | Produto:`, value: `${db3.get(`${id2}.nomeid`)}`})
        .addFields({name:`📦 | Quantidade:`, value: `${db3.get(`${id2}.qtdid`)}`})
        .addFields({name:`💸| Preço:`,value: `${db3.get(`${id2}.precoid`)}`})
        .setColor(config.get(`color`))
      interaction.reply({embeds: [embed], content: "<a:carregando:1162260311240351755> | Encontrado!"})
    }
}