const Discord = require("discord.js")
const { JsonDatabase, } = require("wio.db");
const perms = new JsonDatabase({ databasePath:"./databases/myJsonPerms.json" });
const config = new JsonDatabase({ databasePath:"./config.json" });

module.exports = {
    name: "permadd",
    description: "adicione permissão em alguem!", 
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
        {
            name: "usuario",
            description: "Escolha um Usuario",
            type: Discord.ApplicationCommandOptionType.User,
            required: true,
        },
      ],
    run: async(client, interaction, message, args) => {
      const user2 = interaction.options.getUser("usuario")
      const user = user2.id
      if (interaction.user.id !== config.get(`owner`)) return interaction.reply(`❌ | Apenas o dono do bot pode usar isso!`).then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));
      if(user === `${perms.get(`${user}_id`)}`) return interaction.reply(`❌ | Essa pessoa já tem permissão!`).then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));
      if(isNaN(user)) return interaction.reply(`❌ | Você só pode adicionar IDs!`).then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));
        
      interaction.reply(`<a:carregando:1162260311240351755> | Usuário adicionado!`)
      perms.set(`${user}_id`, user)
    }
}