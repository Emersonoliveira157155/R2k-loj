const Discord = require("discord.js")
const { JsonDatabase, } = require("wio.db");
const config = new JsonDatabase({ databasePath:"./config.json" });
const perms = new JsonDatabase({ databasePath:"./databases/myJsonPerms.json" });
const db = new JsonDatabase({ databasePath:"./databases/myJsonProdutos.json" });

module.exports = {
    name: "setar", 
    description: "Crie um produto", // Coloque a descrição do comando
  type: Discord.ApplicationCommandType.ChatInput,
  options: [
    {
        name: "id",
        description: "Id do produto",
        type: Discord.ApplicationCommandOptionType.String,
        required: true,
    }
],
    run: async(client, interaction, message, args) => {
        const id2 = interaction.options.getString("id")
      if(interaction.user.id !== `${perms.get(`${interaction.user.id}_id`)}`) return interaction.reply(`❌ | Você não está na lista de pessoas!`).then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));
      if(id2 !== `${db.get(`${id2}.idproduto`)}`) return interaction.reply(`❌ | Esse ID de produto não é existente!`).then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));

      const row = new Discord.ActionRowBuilder()               
        .addComponents(
          new Discord.ButtonBuilder()
            .setCustomId(id2)
            .setLabel('Comprar')
            .setEmoji("🛒")
            .setStyle(Discord.ButtonStyle.Success),
      );
        
      const embed = new Discord.EmbedBuilder()
        .setTitle(`${config.get(`title`)} | Bot Store`)
        .setDescription(`
\`\`\`
${db.get(`${id2}.desc`)}
\`\`\`
**🪐 | Nome:** __${db.get(`${id2}.nome`)}__
**💸 | Preço:** __${db.get(`${id2}.preco`)}__
**📦 | Estoque:** __${db.get(`${id2}.conta`).length}__`)
        .setColor(config.get(`color`))
        .setThumbnail(client.user.displayAvatarURL())
      interaction.channel.send({embeds: [embed], components: [row]})
      interaction.reply({content:"enviado com sucesso", ephemeral:true})
    }
}