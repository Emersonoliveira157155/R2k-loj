const Discord = require("discord.js");
const client = new Discord.Client({ intents: 32767 });
const axios = require("axios")
const moment = require("moment")
const { WebhookClient } = require("discord.js")
const confud = require("../config.json")

const { JsonDatabase, } = require("wio.db");
const db = new JsonDatabase({ databasePath:"./databases/myJsonProdutos.json" });
const dbc = new JsonDatabase({ databasePath:"./databases/myJsonCupons.json" });
const db2 = new JsonDatabase({ databasePath:"./databases/myJsonDatabase.json" });
const db3 = new JsonDatabase({ databasePath:"./databases/myJsonIDs.json" });
const perms = new JsonDatabase({ databasePath:"./databases/myJsonPerms.json" });
const config = new JsonDatabase({ databasePath:"./config.json" });



module.exports = {
    name: 'botconfig',
    async execute(interaction, message, client) {
moment.locale("pt-br");




  if (interaction.isButton()) {
    const eprod = db.get(interaction.customId);
      if (!eprod) return;
      const severi = interaction.customId;
        if (eprod) {
          const quantidade = db.get(`${severi}.conta`).length;
          const row = new Discord.ActionRowBuilder()
           .addComponents(
             new Discord.ButtonBuilder()
               .setCustomId(interaction.customId)
               .setLabel('Comprar')
               .setEmoji("🛒")
               .setStyle(Discord.ButtonStyle.Success),
        );
            
        const embed = new Discord.EmbedBuilder()
          .setTitle(`${config.get(`title`)} | Bot Store`)
          .setDescription(`
\`\`\`
${db.get(`${interaction.customId}.desc`)}
\`\`\`
**🪐 | Nome:** __${db.get(`${interaction.customId}.nome`)}__
**💸 | Preço:** __${db.get(`${interaction.customId}.preco`)}__
**📦 | Estoque:** __${db.get(`${interaction.customId}.conta`).length}__`)
          .setColor(config.get(`color`))
          .setThumbnail(
              `${interaction.client.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
        interaction.message.edit({ embeds: [embed], components: [row] })
            
        if (quantidade < 1) {
          const embedsemstock = new Discord.EmbedBuilder()
            .setTitle(`${config.get(`title`)} | Sistema de Vendas`)
            .setDescription(`📰 | Este produto está sem estoque no momento, volte mais tarde!`)
            .setColor(config.get(`color`))
          interaction.reply({ embeds: [embedsemstock], ephemeral: true })
          return;
        }
            
        interaction.deferUpdate()
        if ((interaction.guild.channels.cache.find(c => c.topic === interaction.user.id))) {
          return;
        }
            
        interaction.guild.channels.create({
            name:`🛒・-${interaction.user.username}`,
          type: 0,
          parent: config.get(`category`),
          topic: interaction.user.id,
          permissionOverwrites: [
            {
              id: interaction.guild.id,
              deny: ["ViewChannel"]
            },
            {
             id: confud.role_approved,
             allow: [
                "ViewChannel",
                "SendMessages",
                "AttachFiles",
                "AddReactions",
              ],
            },
            {
             id: interaction.user.id,
             allow: [
                "ViewChannel",
                "SendMessages",
                "AttachFiles",
                "AddReactions",
              ],
           }
         ]
       }).then(c => {
           let quantidade1 = 1;
           let precoalt = eprod.preco;
           var data_id = Math.floor(Math.random() * 999999999999999);
           db3.set(`${data_id}.id`, `${data_id}`)
           db3.set(`${data_id}.status`, `Pendente (1)`)
           db3.set(`${data_id}.userid`, `${interaction.user.id}`)
           db3.set(`${data_id}.dataid`, `${moment().format('LLLL')}`)
           db3.set(`${data_id}.nomeid`, `${eprod.nome}`)
           db3.set(`${data_id}.qtdid`, `${quantidade1}`)
           db3.set(`${data_id}.precoid`, `${precoalt}`)
           db3.set(`${data_id}.entrid`, `Andamento`)
           const timer2 = setTimeout(function () {
             if ((interaction.guild.channels.cache.find(c => c.topic === interaction.user.id))) { c.delete(); }
             db3.delete(`${data_id}`)
           }, 300000)
                     
           const row = new Discord.ActionRowBuilder()
             .addComponents(
               new Discord.ButtonBuilder()
                 .setCustomId('removeboton')
                 .setLabel('Remover')
                 .setEmoji("🗑️")
                 .setStyle(Discord.ButtonStyle.Danger),
           )
             .addComponents(
               new Discord.ButtonBuilder()
                 .setCustomId('comprarboton')
                 .setLabel('Comprar')
                 .setEmoji('🛒')
                 .setStyle(Discord.ButtonStyle.Success),
           )
             .addComponents(
               new Discord.ButtonBuilder()
                 .setCustomId('addboton')
                 .setLabel('Adicionar')
                 .setEmoji('<:maiscash:1119473561673932821>')
                 .setStyle(Discord.ButtonStyle.Secondary),
           )
             .addComponents(
               new Discord.ButtonBuilder()
                 .setCustomId('cancelarbuy')
                 .setLabel('Cancelar')
                 .setStyle(Discord.ButtonStyle.Danger),
           );
           const embedss = new Discord.EmbedBuilder()
             .setTitle(`${config.get(`title`)} | Sistema de Compras`)
             .addFields({name: `🪐 | Nome:`, value: eprod.nome})
             .addFields({name: `📦 | Quantidade:`, value:`${quantidade1}`})
             .addFields({name: `💸 | Valor`, value:`${precoalt} `}) 
             .addFields({name: `🪪 | Id da compra`,value: `${data_id}`}) 
             .setColor(config.get(`color`))
             .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
           c.send({ embeds: [embedss], content: `<@${interaction.user.id}>`, components: [row], fetchReply: true }).then(msg => {
             const filter = i => i.user.id === interaction.user.id;
             const collector = msg.createMessageComponentCollector({ filter });
             collector.on("collect", intera => {
               intera.deferUpdate()
               if (intera.customId === 'cancelarbuy') {
                 clearInterval(timer2);
                 const embedcancelar = new Discord.EmbedBuilder()
                            .setTitle(`${config.get(`title`)} | A Compra que você iria fazer, foi cancelada`)
                            .setDescription(`❌ | Você acabou cancelando a Compra, e o estoque foi restornado!`)
                            .setColor(config.get(`color`))
                            .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                            interaction.user.send({embeds: [embedcancelar]})
                 db3.delete(`${data_id}`)
                 if ((interaction.guild.channels.cache.find(c => c.topic === interaction.user.id))) { c.delete(); }
               }
               if (intera.customId === "addboton") {
                 if (quantidade1++ >= quantidade) {
                   quantidade1--;
                   const embedss2 = new Discord.EmbedBuilder()
                     .setTitle(`${config.get(`title`)} | Sistema de Compras`)
                     .addFields({name: `🪐 | Nome:`,value: `${eprod.nome}`})
                     .addFields({name: `📦 | Quantidade:`,value: `${quantidade1}`})
                     .addFields({name: `💸 | Valor`, value: `${precoalt} `}) 
                     .addFields({name: `🪪 | Id da compra`,value: `${data_id}`}) 
                     .setColor(config.get(`color`))
                     .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                   msg.edit({ embeds: [embedss2] })
                 } else {
                   precoalt = Number(precoalt) + Number(eprod.preco);
                   const embedss = new Discord.EmbedBuilder()
                     .setTitle(`${config.get(`title`)} | Sistema de Compras`)
                     .addFields({name: `🪐 | Nome:`,value: `${eprod.nome}`})
                     .addFields({name: `📦 | Quantidade:`,value: `${quantidade1}`})
                     .addFields({name: `💸 | Valor`,value: `${precoalt} `}) 
                     .addFields({name: `🪪 | Id da compra`,value: `${data_id}`}) 
                     .setColor(config.get(`color`))
                     .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                   msg.edit({ embeds: [embedss] })
                 }
               }
                 if (intera.customId === "removeboton") {
                   if (quantidade1 <= 1) {
                     } else {
                       precoalt = precoalt - eprod.preco;
                       quantidade1--;
                       const embedss = new Discord.EmbedBuilder()
                         .setTitle(`${config.get(`title`)} | Sistema de Compras`)                        
                         .addFields({name: `🪐 | Nome:`,value: `${eprod.nome}`})
                         .addFields({name: `📦 | Quantidade:`,value: `${quantidade1}`})
                         .addFields({name: `💸 | Valor`,value: `${precoalt} `}) 
                         .addFields({name: `🪪 | Id da compra`,value: `${data_id}`}) 
                         .setColor(config.get(`color`))
                         .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                       msg.edit({ embeds: [embedss] })
                     }
                   }
                 
                   if (intera.customId === "comprarboton") {
                    // msg.channel.bulkDelete(50);
                    // clearInterval(timer2);
                    // const timer3 = setTimeout(function () {
                    //  if ((interaction.guild.channels.cache.find(c => c.topic === interaction.user.id))) { c.delete(); }
                    //   db3.delete(`${data_id}`)
                    //  }, 300000)
                     const row = new Discord.ActionRowBuilder()
                       .addComponents(
                         new Discord.ButtonBuilder()
                           .setCustomId('addcboton')
                           .setLabel('Cupom')
                           .setEmoji("<:maiscash:1119473561673932821>")
                           .setStyle(Discord.ButtonStyle.Success),
                     )
                       .addComponents(
                         new Discord.ButtonBuilder()
                           .setCustomId('continuarboton')
                           .setLabel('Continuar')
                           .setEmoji("🔰")
                           .setStyle(Discord.ButtonStyle.Success),
                     )
                       .addComponents(
                         new Discord.ButtonBuilder()
                           .setCustomId('cancelarboton')
                           .setLabel('Cancelar')
                           
                           .setStyle(Discord.ButtonStyle.Danger),
                     );
                                        
                     const embedss = new Discord.EmbedBuilder()
                       .setTitle(`${config.get(`title`)} | Sistema de Compras`)
                       .addFields({name: `🚀 | Cupom:`,value: `Nenhum`})
                       .addFields({name: `📝 | Desconto:`,value: `0.00%`})
                       .addFields({name: `💸 | Preço Atual:`, value: `${precoalt}`}) 
                       .setColor(config.get(`color`))
                       .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                     msg.edit({ embeds: [embedss], components: [row], content: `<@${interaction.user.id}>`, fetchReply: true }).then(msg => {
                       const filter = i => i.user.id === interaction.user.id;
                       const collector = msg.createMessageComponentCollector({ filter });
                       collector.on("collect", intera2 => {
                         intera2.deferUpdate()
                         if (intera2.customId === 'addcboton') {
                           
                            msg.channel.send("❓ | Qual o cupom?").then(mensagem => {
                             const filter = m => m.author.id === interaction.user.id;
                             const collector = mensagem.channel.createMessageCollector({ filter, max: 1 });
                             collector.on("collect", cupom => {
                               if(`${cupom}` !== `${dbc.get(`${cupom}.idcupom`)}`) {
                                 cupom.delete()
                                 mensagem.edit("❌ | Isso não é um cupom!")
                                 
                                 return;
                               }
                                 
                               var minalt = dbc.get(`${cupom}.minimo`);
                               var dscalt = dbc.get(`${cupom}.desconto`);
                               var qtdalt = dbc.get(`${cupom}.quantidade`);
                                 
                               precoalt = Number(precoalt) + Number(`1`);
                               minalt = Number(minalt) + Number(`1`);
                               if(precoalt < minalt) {
                                 cupom.delete()
                                 
                                 mensagem.edit(`❌ | Você não atingiu o mínimo!`)
                                 return;
                               } else {
                              
                               precoalt = Number(precoalt) - Number(`1`);
                               minalt = Number(minalt) - Number(`1`);
                                   
                               if(`${dbc.get(`${cupom}.quantidade`)}` === "0") {
                                 cupom.delete()
                                 
                                 mensagem.edit("❌ | Esse cupom saiu de estoque!")
                                 return;
                               }
                                              
                               if(`${cupom}` === `${dbc.get(`${cupom}.idcupom`)}`) {
                                 cupom.delete()
                                 mensagem.edit("✅ | Cupom adicionado")
                                  
                                   var precinho = precoalt;
                                   var descontinho = "0."+dscalt;
                                   var cupomfinal = precinho * descontinho;
                                   precoalt = precinho - cupomfinal;
                                   qtdalt = qtdalt - 1;
                                   row.components[0].setDisabled(true)
                                   const embedss2 = new Discord.EmbedBuilder()
                                     .setTitle(`${config.get(`title`)} | Sistema de Compras`)
                                     .addFields({name: `🚀 | Cupom:`,value: `${dbc.get(`${cupom}.idcupom`)}`})
                                     .addFields({name: `📝 | Desconto:`,value: `${dbc.get(`${cupom}.desconto`)}.00%`})
                                     .addFields({name:`💸 | Preço Atual:`,value: `${precoalt} `})
                                     .setColor(config.get(`color`))
                                     .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                                   msg.edit({ embeds: [embedss2], components: [row], content: `<@${interaction.user.id}>`, fetchReply: true })
                                   dbc.set(`${cupom}.quantidade`, `${qtdalt}`)
                                 }
                               }
                              }) 
                            })
                          }
                                    
                           if (intera2.customId === 'cancelarboton') {
                             clearInterval(timer3);
                             const embedcancelar2 = new Discord.EmbedBuilder()
                            .setTitle(`${config.get(`title`)} | A Compra que você iria fazer, foi cancelada`)
                            .setDescription(`❌ | Você acabou cancelando a Compra, e o estoque foi restornado!`)
                            .setColor(config.get(`color`))
                            .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                            interaction.user.send({embeds: [embedcancelar2]})
                             db3.delete(`${data_id}`)
                             if ((interaction.guild.channels.cache.find(c => c.topic === interaction.user.id))) { c.delete(); }
                           }

                           if (intera2.customId === "continuarboton") {
                             //msg.channel.bulkDelete(50);
                             //clearInterval(timer3);
                             //const venda = setTimeout(function () {
                             // if ((interaction.guild.channels.cache.find(c => c.topic === interaction.user.id))) { c.delete(); }
                             //  db3.delete(`${data_id}`)
                             // }, 1800000)
                              
                             

                             
                                 db3.set(`${data_id}.status`, `Pendente (2)`)
                                 const attachment = confud.pix.qrcode
                                 const row = new Discord.ActionRowBuilder()
                                   .addComponents(
                                     new Discord.ButtonBuilder()
                                       .setCustomId('codigo')
                                       .setEmoji("📋")
                                       .setLabel("Copia e Cola")
                                       .setStyle(Discord.ButtonStyle.Secondary),
                                 )
                                   .addComponents(
                                     new Discord.ButtonBuilder()
                                       .setCustomId('qrcode')
                                       .setEmoji("🪟")
                                       .setLabel("QR Code")
                                       .setStyle(Discord.ButtonStyle.Success),
                                 )
                                 .addComponents(
                                    new Discord.ButtonBuilder()
                                      .setCustomId('cancelarpix')
                                      .setEmoji("🗑")
                                      .setLabel("Cancelar")
                                      .setStyle(Discord.ButtonStyle.Danger),
                                ).addComponents(
                                    new Discord.ButtonBuilder()
                                      .setCustomId('aprovarcompra')
                                      .setEmoji("✅")
                                      .setLabel("Aprovar")
                                      .setStyle(Discord.ButtonStyle.Success),
                                );;
                                const embed = new Discord.EmbedBuilder()
                                  .setTitle(`${config.get(`title`)} | Sistema de Compras`)
                                  .setDescription(`
\`\`\`
Pague para receber o produto.
\`\`\``)
                                  .addFields({name: `🪐 | Nome:`,value: `${eprod.nome}`})
                                  .addFields({name: `📦 | Quantidade:`,value: `${quantidade1}`})
                                  .addFields({name: `💸 | Valor`,value: `${precoalt} `}) 
                                  .addFields({name: `🪪 | Id da compra`,value: `${data_id}`}) 
                                  .setColor(config.get(`color`))
                                  .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                                msg.edit({ embeds: [embed], content: `<@${interaction.user.id}>`, components: [row] }).then(msg => {

                                const collector = msg.channel.createMessageComponentCollector();
                                                    collector.on("collect", interaction => {
                                                        if(interaction.customId === "aprovarcompra"){
                                                            if(interaction.user.id !== `${perms.get(`${interaction.user.id}_id`)}`) return interaction.reply(`❌ | Você não tem permissão de aprovar!`)
                                                         const vendadel = setTimeout(function () {
                                    if ((interaction.guild.channels.cache.find(c => c.topic === interaction.user.id))) { c.delete(); }}, 60000)
                                   const a = db.get(`${severi}.conta`);
                                   const canalif1 = interaction.client.channels.cache.get(config.canallogs);
                                     db2.add("pedidostotal", 1)
                                     db2.add("gastostotal", Number(precoalt))
                                     db2.add(`${moment().format('L')}.pedidos`, 1)
                                     db2.add(`${moment().format('L')}.recebimentos`, Number(precoalt))
                                     db2.add(`${interaction.user.id}.gastosaprovados`, Number(precoalt))
                                     db2.add(`${interaction.user.id}.pedidosaprovados`, 1)

                                     if (a < quantidade1) {}
                                     
                                     else {
                                           const removed = a.splice(0, Number(quantidade1));
                                            db.set(`${severi}.conta`, a);
                                             const embedentrega = new Discord.EmbedBuilder()
                                               .setTitle(`${config.get(`title`)} | Seu produto`)
                                               .setDescription(`**🪪 | Produtos:** \n  \`\`\` 1º| ${removed.join("\n")}\`\`\`\n**🪪 | Id da Compra:** ${data_id} `)
                                               .setColor(config.get(`color`))
                                               .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                                             interaction.user.send({ embeds: [embedentrega] })
                                              db3.set(`${data_id}.status`, `Concluido`)
                                              msg.channel.send("🔰 | Pagamento aprovado verifique a sua dm!")
                                              msg.channel.send(`🔰 | ID Da compra: ||${data_id}||`)
                                              msg.channel.send("🔰 | Carrinho fechara em 3 minutos")
                                              const roleId = config.get('role');
                                              const role = interaction.guild.roles.cache.get(roleId);
                                              
                                              if (role) {
                                                
                                                const membro = interaction.guild.members.cache.get(interaction.user.id);
                                              
                                                
                                                if (membro) {
                                                  
                                                  membro.roles.add(role)
                                                    .then(() => {
                                                     
                                                      console.log('Função adicionada com sucesso.');
                                                    })
                                                    .catch(error => {
                                                     
                                                      console.error('Erro ao adicionar a função:', error);
                                                    });
                                                } else {
                                                  console.error('Membro não encontrado.');
                                                }
                                              } else {
                                                console.error('Função não encontrada.');
                                              }

                                                              
                                             let sleep = async (ms) => await new Promise(r => setTimeout(r,ms));
                                             let avaliacao = "Nenhuma avaliação enviada..."
                                             const embed = msg.reply({ embeds: [
                                                new Discord.EmbedBuilder()
                                               .setTitle(`${config.get(`title`)} | Avaliação`)
                                               .addFields({name: `📰 Informações:`, value: `Abra Ticket para quaisquer duvida!`})
                                               .addFields({name: `⭐ Estrelas:`,value: `Aguardando...`})
                                               .setColor(config.get(`color`))],
                                               })
                                        
                                             const interacaoavaliar = msg.createMessageComponentCollector({ componentType: Discord.ComponentType.Button, });
                                             interacaoavaliar.on("collect", async (interaction) => {
                                               if (interaction.user.id != interaction.user.id) {
                                                 return;
                                               }
                             
                                            
                                               })
                                                                
                                               const embedaprovadolog = new Discord.EmbedBuilder()
                                               .setTitle(`${config.get(`title`)} | Compra Aprovada`)
                                               .addFields({name: `👦 | Comprador:`,value:  `<@${interaction.user.id}>`})
                                               .addFields({name: `📅 | Data da compra:`,value: `${moment().format('LLLL')}`})
                                               .addFields({name: `🛒 | Produto:`, value: `${eprod.nome}`})
                                               .addFields({name: `📦 | Quantidade:`,value: `${quantidade1}x`})
                                               .addFields({name: `💸 | Valor Pago:`,value: `R$${precoalt}`})
                                               .addFields({name: `🪪 | Id da compra:`,value: `${data_id}`})
                                               .setColor(config.get(`color`))
                                               .setThumbnail(
        `${interaction.user.displayAvatarURL({
          dynamic: true,
          format: "png",
          size: 4096,
        })}`
      )
                                             const channesls = interaction.client.channels.cache.get(config.get(`logs`))
                                             channesls.send({embeds: [embedaprovadolog]})
                                               const canalif = interaction.client.channels.cache.get(config.get(`logs_staff`))
                                               canalif.send({ embeds: [
                                                new Discord.EmbedBuilder()
                                                 .setTitle(`${config.get(`title`)} | Compra Aprovada`)
                                                 .addFields({name: `👦 | Comprador:`,value: `${interaction.user}`})
                                                 .addFields({name: `📅 | Data da compra:`,value: `${moment().format('LLLL')}`})
                                                 .addFields({name: `🛒 | Produto:`, value: `${eprod.nome}`})
                                                 .addFields({name: `📦 | Quantidade:`,value: `${quantidade1}x`})
                                                 .addFields({name: `💸 | Preço:`,value: `${precoalt}`})
                                                 .addFields({name: `🪪 | Id da compra:`,value: `${data_id}`})
                                                 .addFields({name: `Produto Entregue: `, value: `\`\`\`${removed.join(" \n")}\`\`\``})
                                                 .setColor(config.get(`color`))
                                                 .setThumbnail(
                                                      `${interaction.user.displayAvatarURL({
                                                        dynamic: true,
                                                        format: "png",
                                                     size: 4096,
                                                  })}`
                                                 )]})

                                                msg.edit({components:[]})
                                                        }   
                                                        }
                                                     if (interaction.customId === 'codigo') {
                                                      row.components[0].setDisabled(true)
                                                      interaction.reply(confud.pix.chave_pix)
                                                       const embed = new Discord.EmbedBuilder()
                                                         .setTitle(`${config.get(`title`)} | Sistema de Compras`)
                                                         .setDescription(`
\`\`\`
Pague para receber o produto.
\`\`\``)
                                                         .addFields({name: `🪐 | Nome:`,value: `${eprod.nome}`})
                                                         .addFields({name: `📦 | Quantidade:`,value: `${quantidade1}`})
                                                         .addFields({name: `💸 | Valor`,value: `${precoalt} `}) 
                                                         .addFields({name: `🪪 | Id da compra`,value: `${data_id}`}) 
                                                         .setColor(config.get(`color`))
                                                         .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                                                         
                                                         msg.edit({ embeds: [embed], content: `<@${interaction.user.id}>`, components: [row] })
                                                       }
                                                    
                                                       if (interaction.customId === 'qrcode') {
                                                        row.components[1].setDisabled(true)
                                                        const embed2 = new Discord.EmbedBuilder()
                                                          .setTitle(`${config.get(`title`)} | Sistema de Compras`)
                                                          .setDescription(`
\`\`\`
Pague para receber o produto.
\`\`\``)
                                                          .addFields({name: `🪐 | Nome:`,value: `${eprod.nome}`})
                                                          .addFields({name: `📦 | Quantidade:`,value: `${quantidade1}`})
                                                          .addFields({name: `💸 | Valor`,value: `${precoalt} `}) 
                                                          .addFields({name: `🪪 | Id da compra`,value: `${data_id}`}) 
                                                          .setColor(config.get(`color`))
                                                          .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                                                        msg.edit({ embeds: [embed2], content: `<@${interaction.user.id}>`, components: [row] })
                                                        
                                                        const embed = new Discord.EmbedBuilder()
                                                          .setTitle(`${config.get(`title`)} | QR Code`)
                                                          .setDescription(`Aponte a camera do seu dispositivo para o qrcode e escaneio-o, feito isso basta efetuar o pagamento e aguardar alguns segundos.`)
                                                          .setImage(confud.pix.qrcode)
                                                          .setColor(config.get(`color`))
                                                        interaction.reply({ embeds: [embed]})
                                                       }
                                                    
                                                       if (interaction.customId === 'cancelarpix') {
                                                         clearInterval(lopp);
                                                         clearInterval(venda)
                                                         const embedcancelar3 = new Discord.EmbedBuilder()
                            .setTitle(`${config.get(`title`)} | A Compra que você iria fazer, foi cancelada`)
                            .setDescription(`❌ | Você acabou cancelando a Compra, e o estoque foi restornado!`)
                            .setColor(config.get(`color`))
                            .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                            interaction.user.send({embeds: [embedcancelar3]})
                                                         db3.delete(`${data_id}`)
                                                         if ((interaction.guild.channels.cache.find(c => c.topic === interaction.user.id))) { c.delete(); }
                                                        }
                                                      })
                                                    })
                                                  
             
                                           }
                                        })}
                                       
                                     
                                   )}})})})}}}}
